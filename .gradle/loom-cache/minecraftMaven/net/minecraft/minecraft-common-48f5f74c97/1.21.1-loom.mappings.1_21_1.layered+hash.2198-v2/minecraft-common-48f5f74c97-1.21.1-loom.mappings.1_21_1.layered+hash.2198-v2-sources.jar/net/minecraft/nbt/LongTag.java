package net.minecraft.nbt;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class LongTag extends NumericTag {
	private static final int SELF_SIZE_IN_BYTES = 16;
	public static final TagType<LongTag> TYPE = new TagType.StaticSize<LongTag>() {
		public LongTag load(DataInput dataInput, NbtAccounter nbtAccounter) throws IOException {
			return LongTag.valueOf(readAccounted(dataInput, nbtAccounter));
		}

		@Override
		public StreamTagVisitor.ValueResult parse(DataInput dataInput, StreamTagVisitor streamTagVisitor, NbtAccounter nbtAccounter) throws IOException {
			return streamTagVisitor.visit(readAccounted(dataInput, nbtAccounter));
		}

		private static long readAccounted(DataInput dataInput, NbtAccounter nbtAccounter) throws IOException {
			nbtAccounter.accountBytes(16L);
			return dataInput.readLong();
		}

		@Override
		public int size() {
			return 8;
		}

		@Override
		public String getName() {
			return "LONG";
		}

		@Override
		public String getPrettyName() {
			return "TAG_Long";
		}

		@Override
		public boolean isValue() {
			return true;
		}
	};
	private final long data;

	LongTag(long l) {
		this.data = l;
	}

	public static LongTag valueOf(long l) {
		return l >= -128L && l <= 1024L ? LongTag.Cache.cache[(int)l - -128] : new LongTag(l);
	}

	@Override
	public void write(DataOutput dataOutput) throws IOException {
		dataOutput.writeLong(this.data);
	}

	@Override
	public int sizeInBytes() {
		return 16;
	}

	@Override
	public byte getId() {
		return 4;
	}

	@Override
	public TagType<LongTag> getType() {
		return TYPE;
	}

	public LongTag copy() {
		return this;
	}

	public boolean equals(Object object) {
		return this == object ? true : object instanceof LongTag && this.data == ((LongTag)object).data;
	}

	public int hashCode() {
		return (int)(this.data ^ this.data >>> 32);
	}

	@Override
	public void accept(TagVisitor tagVisitor) {
		tagVisitor.visitLong(this);
	}

	@Override
	public long getAsLong() {
		return this.data;
	}

	@Override
	public int getAsInt() {
		return (int)(this.data & -1L);
	}

	@Override
	public short getAsShort() {
		return (short)(this.data & 65535L);
	}

	@Override
	public byte getAsByte() {
		return (byte)(this.data & 255L);
	}

	@Override
	public double getAsDouble() {
		return this.data;
	}

	@Override
	public float getAsFloat() {
		return (float)this.data;
	}

	@Override
	public Number getAsNumber() {
		return this.data;
	}

	@Override
	public StreamTagVisitor.ValueResult accept(StreamTagVisitor streamTagVisitor) {
		return streamTagVisitor.visit(this.data);
	}

	static class Cache {
		private static final int HIGH = 1024;
		private static final int LOW = -128;
		static final LongTag[] cache = new LongTag[1153];

		private Cache() {
		}

		static {
			for (int i = 0; i < cache.length; i++) {
				cache[i] = new LongTag(-128 + i);
			}
		}
	}
}
