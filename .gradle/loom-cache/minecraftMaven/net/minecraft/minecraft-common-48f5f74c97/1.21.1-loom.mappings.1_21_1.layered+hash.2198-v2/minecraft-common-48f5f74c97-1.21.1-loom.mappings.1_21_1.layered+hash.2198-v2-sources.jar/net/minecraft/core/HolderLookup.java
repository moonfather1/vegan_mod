package net.minecraft.core;

import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.Lifecycle;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.core.HolderLookup.Provider.1;
import net.minecraft.core.HolderLookup.Provider.2;
import net.minecraft.resources.RegistryOps;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.flag.FeatureElement;
import net.minecraft.world.flag.FeatureFlagSet;

public interface HolderLookup<T> extends HolderGetter<T> {
	Stream<Holder.Reference<T>> listElements();

	default Stream<ResourceKey<T>> listElementIds() {
		return this.listElements().map(Holder.Reference::key);
	}

	Stream<HolderSet.Named<T>> listTags();

	default Stream<TagKey<T>> listTagIds() {
		return this.listTags().map(HolderSet.Named::key);
	}

	public interface Provider {
		Stream<ResourceKey<? extends Registry<?>>> listRegistries();

		<T> Optional<HolderLookup.RegistryLookup<T>> lookup(ResourceKey<? extends Registry<? extends T>> resourceKey);

		default <T> HolderLookup.RegistryLookup<T> lookupOrThrow(ResourceKey<? extends Registry<? extends T>> resourceKey) {
			return (HolderLookup.RegistryLookup<T>)this.lookup(resourceKey)
				.orElseThrow(() -> new IllegalStateException("Registry " + resourceKey.location() + " not found"));
		}

		default <V> RegistryOps<V> createSerializationContext(DynamicOps<V> dynamicOps) {
			return RegistryOps.create(dynamicOps, this);
		}

		default HolderGetter.Provider asGetterLookup() {
			return new 1(this);
		}

		static HolderLookup.Provider create(Stream<HolderLookup.RegistryLookup<?>> stream) {
			Map<ResourceKey<? extends Registry<?>>, HolderLookup.RegistryLookup<?>> map = (Map<ResourceKey<? extends Registry<?>>, HolderLookup.RegistryLookup<?>>)stream.collect(
				Collectors.toUnmodifiableMap(HolderLookup.RegistryLookup::key, registryLookup -> registryLookup)
			);
			return new 2(map);
		}
	}

	public interface RegistryLookup<T> extends HolderLookup<T>, HolderOwner<T> {
		ResourceKey<? extends Registry<? extends T>> key();

		Lifecycle registryLifecycle();

		default HolderLookup.RegistryLookup<T> filterFeatures(FeatureFlagSet featureFlagSet) {
			return FeatureElement.FILTERED_REGISTRIES.contains(this.key()) ? this.filterElements(object -> ((FeatureElement)object).isEnabled(featureFlagSet)) : this;
		}

		default HolderLookup.RegistryLookup<T> filterElements(Predicate<T> predicate) {
			return new net.minecraft.core.HolderLookup.RegistryLookup.1(this, predicate);
		}
	}
}
