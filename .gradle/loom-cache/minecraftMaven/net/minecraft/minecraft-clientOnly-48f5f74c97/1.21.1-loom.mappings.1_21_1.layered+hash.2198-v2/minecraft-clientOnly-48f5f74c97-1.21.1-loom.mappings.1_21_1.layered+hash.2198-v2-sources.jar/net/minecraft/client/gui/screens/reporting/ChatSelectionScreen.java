package net.minecraft.client.gui.screens.reporting;

import com.mojang.authlib.minecraft.report.AbuseReportLimits;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.GuiMessageTag;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineLabel;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.navigation.ScreenDirection;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.reporting.ChatSelectionLogFiller.Output;
import net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.DividerEntry;
import net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Heading;
import net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.MessageEntry;
import net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.MessageHeadingEntry;
import net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.PaddingEntry;
import net.minecraft.client.multiplayer.chat.ChatTrustLevel;
import net.minecraft.client.multiplayer.chat.LoggedChatMessage;
import net.minecraft.client.multiplayer.chat.LoggedChatMessage.Player;
import net.minecraft.client.multiplayer.chat.report.ReportingContext;
import net.minecraft.client.multiplayer.chat.report.ChatReport.Builder;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class ChatSelectionScreen extends Screen {
	static final ResourceLocation CHECKMARK_SPRITE = ResourceLocation.withDefaultNamespace("icon/checkmark");
	private static final Component TITLE = Component.translatable("gui.chatSelection.title");
	private static final Component CONTEXT_INFO = Component.translatable("gui.chatSelection.context");
	@Nullable
	private final Screen lastScreen;
	private final ReportingContext reportingContext;
	private Button confirmSelectedButton;
	private MultiLineLabel contextInfoLabel;
	@Nullable
	private ChatSelectionScreen.ChatSelectionList chatSelectionList;
	final Builder report;
	private final Consumer<Builder> onSelected;
	private ChatSelectionLogFiller chatLogFiller;

	public ChatSelectionScreen(@Nullable Screen screen, ReportingContext reportingContext, Builder builder, Consumer<Builder> consumer) {
		super(TITLE);
		this.lastScreen = screen;
		this.reportingContext = reportingContext;
		this.report = builder.copy();
		this.onSelected = consumer;
	}

	@Override
	protected void init() {
		this.chatLogFiller = new ChatSelectionLogFiller(this.reportingContext, this::canReport);
		this.contextInfoLabel = MultiLineLabel.create(this.font, CONTEXT_INFO, this.width - 16);
		this.chatSelectionList = this.addRenderableWidget(new ChatSelectionScreen.ChatSelectionList(this.minecraft, (this.contextInfoLabel.getLineCount() + 1) * 9));
		this.addRenderableWidget(Button.builder(CommonComponents.GUI_BACK, button -> this.onClose()).bounds(this.width / 2 - 155, this.height - 32, 150, 20).build());
		this.confirmSelectedButton = this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, button -> {
			this.onSelected.accept(this.report);
			this.onClose();
		}).bounds(this.width / 2 - 155 + 160, this.height - 32, 150, 20).build());
		this.updateConfirmSelectedButton();
		this.extendLog();
		this.chatSelectionList.setScrollAmount(this.chatSelectionList.getMaxScroll());
	}

	private boolean canReport(LoggedChatMessage loggedChatMessage) {
		return loggedChatMessage.canReport(this.report.reportedProfileId());
	}

	private void extendLog() {
		int i = this.chatSelectionList.getMaxVisibleEntries();
		this.chatLogFiller.fillNextPage(i, this.chatSelectionList);
	}

	void onReachedScrollTop() {
		this.extendLog();
	}

	void updateConfirmSelectedButton() {
		this.confirmSelectedButton.active = !this.report.reportedMessages().isEmpty();
	}

	@Override
	public void render(GuiGraphics guiGraphics, int i, int j, float f) {
		super.render(guiGraphics, i, j, f);
		guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 10, 16777215);
		AbuseReportLimits abuseReportLimits = this.reportingContext.sender().reportLimits();
		int k = this.report.reportedMessages().size();
		int l = abuseReportLimits.maxReportedMessageCount();
		Component component = Component.translatable("gui.chatSelection.selected", new Object[]{k, l});
		guiGraphics.drawCenteredString(this.font, component, this.width / 2, 16 + 9 * 3 / 2, -1);
		this.contextInfoLabel.renderCentered(guiGraphics, this.width / 2, this.chatSelectionList.getFooterTop());
	}

	@Override
	public void onClose() {
		this.minecraft.setScreen(this.lastScreen);
	}

	@Override
	public Component getNarrationMessage() {
		return CommonComponents.joinForNarration(new Component[]{super.getNarrationMessage(), CONTEXT_INFO});
	}

	@Environment(EnvType.CLIENT)
	public class ChatSelectionList
		extends ObjectSelectionList<net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Entry>
		implements Output {
		@Nullable
		private Heading previousHeading;

		public ChatSelectionList(final Minecraft minecraft, final int i) {
			super(minecraft, ChatSelectionScreen.this.width, ChatSelectionScreen.this.height - i - 80, 40, 16);
		}

		@Override
		public void setScrollAmount(double d) {
			double e = this.getScrollAmount();
			super.setScrollAmount(d);
			if (this.getMaxScroll() > 1.0E-5F && d <= 1.0E-5F && !Mth.equal(d, e)) {
				ChatSelectionScreen.this.onReachedScrollTop();
			}
		}

		@Override
		public void acceptMessage(int i, Player player) {
			boolean bl = player.canReport(ChatSelectionScreen.this.report.reportedProfileId());
			ChatTrustLevel chatTrustLevel = player.trustLevel();
			GuiMessageTag guiMessageTag = chatTrustLevel.createTag(player.message());
			net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Entry entry = new MessageEntry(
				this, i, player.toContentComponent(), player.toNarrationComponent(), guiMessageTag, bl, true
			);
			this.addEntryToTop(entry);
			this.updateHeading(player, bl);
		}

		private void updateHeading(Player player, boolean bl) {
			net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Entry entry = new MessageHeadingEntry(
				this, player.profile(), player.toHeadingComponent(), bl
			);
			this.addEntryToTop(entry);
			Heading heading = new Heading(player.profileId(), entry);
			if (this.previousHeading != null && this.previousHeading.canCombine(heading)) {
				this.removeEntryFromTop(this.previousHeading.entry());
			}

			this.previousHeading = heading;
		}

		@Override
		public void acceptDivider(Component component) {
			this.addEntryToTop(new PaddingEntry(this));
			this.addEntryToTop(new DividerEntry(this, component));
			this.addEntryToTop(new PaddingEntry(this));
			this.previousHeading = null;
		}

		@Override
		public int getRowWidth() {
			return Math.min(350, this.width - 50);
		}

		public int getMaxVisibleEntries() {
			return Mth.positiveCeilDiv(this.height, this.itemHeight);
		}

		@Override
		protected void renderItem(GuiGraphics guiGraphics, int i, int j, float f, int k, int l, int m, int n, int o) {
			net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Entry entry = this.getEntry(k);
			if (this.shouldHighlightEntry(entry)) {
				boolean bl = this.getSelected() == entry;
				int p = this.isFocused() && bl ? -1 : -8355712;
				this.renderSelection(guiGraphics, m, n, o, p, -16777216);
			}

			entry.render(guiGraphics, k, m, l, n, o, i, j, this.getHovered() == entry, f);
		}

		private boolean shouldHighlightEntry(net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Entry entry) {
			if (entry.canSelect()) {
				boolean bl = this.getSelected() == entry;
				boolean bl2 = this.getSelected() == null;
				boolean bl3 = this.getHovered() == entry;
				return bl || bl2 && bl3 && entry.canReport();
			} else {
				return false;
			}
		}

		@Nullable
		protected net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Entry nextEntry(ScreenDirection screenDirection) {
			return this.nextEntry(screenDirection, net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Entry::canSelect);
		}

		public void setSelected(@Nullable net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Entry entry) {
			super.setSelected(entry);
			net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Entry entry2 = this.nextEntry(ScreenDirection.UP);
			if (entry2 == null) {
				ChatSelectionScreen.this.onReachedScrollTop();
			}
		}

		@Override
		public boolean keyPressed(int i, int j, int k) {
			net.minecraft.client.gui.screens.reporting.ChatSelectionScreen.ChatSelectionList.Entry entry = this.getSelected();
			return entry != null && entry.keyPressed(i, j, k) ? true : super.keyPressed(i, j, k);
		}

		public int getFooterTop() {
			return this.getBottom() + 9;
		}
	}
}
