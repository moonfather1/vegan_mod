package net.minecraft.client.multiplayer;

import com.mojang.authlib.GameProfile;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.telemetry.WorldSessionTelemetryManager;
import net.minecraft.core.RegistryAccess.Frozen;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.ServerLinks;
import net.minecraft.world.flag.FeatureFlagSet;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public record CommonListenerCookie(
	GameProfile localGameProfile,
	WorldSessionTelemetryManager telemetryManager,
	Frozen receivedRegistries,
	FeatureFlagSet enabledFeatures,
	@Nullable String serverBrand,
	@Nullable ServerData serverData,
	@Nullable Screen postDisconnectScreen,
	Map<ResourceLocation, byte[]> serverCookies,
	@Nullable ChatComponent.State chatState,
	@Deprecated(forRemoval = true) boolean strictErrorHandling,
	Map<String, String> customReportDetails,
	ServerLinks serverLinks
) {
}
